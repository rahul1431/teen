import { Pool } from 'pg'

const ODDS_API_KEY = process.env.ODDS_API_KEY || ''
const SPORTS = ['cricket_test_match', 'cricket_odi', 'cricket_t20', 'cricket_ipl']

interface OddsOutcome {
  name: string
  price: number
}

interface OddsMarket {
  key: string
  outcomes: OddsOutcome[]
}

interface OddsBookmaker {
  key: string
  title: string
  markets: OddsMarket[]
}

interface OddsEvent {
  id: string
  sport_key: string
  commence_time: string
  home_team: string
  away_team: string
  bookmakers: OddsBookmaker[]
}

// Helper to fuzzy match team names
function teamMatches(dbName: string, apiName: string): boolean {
  const cleanDb = dbName.toLowerCase().replace(/[^a-z0-9]/g, '')
  const cleanApi = apiName.toLowerCase().replace(/[^a-z0-9]/g, '')
  return cleanDb.includes(cleanApi) || cleanApi.includes(cleanDb)
}

export async function syncMatchOdds(db: Pool): Promise<void> {
  if (!ODDS_API_KEY) {
    console.log('[Odds Sync] Skipping odds sync: ODDS_API_KEY not configured')
    return
  }

  // Fetch active matches from DB
  const dbMatches = await db.query(
    "SELECT id, team_a, team_b, start_time FROM cricket_matches WHERE status IN ('upcoming', 'live')"
  )
  if (!dbMatches.rows.length) return

  // Query The Odds API for each sport
  for (const sport of SPORTS) {
    try {
      const url = `https://api.the-odds-api.com/v4/sports/${sport}/odds/?apiKey=${ODDS_API_KEY}&regions=us,uk,au&markets=h2h`
      const res = await fetch(url)
      if (!res.ok) {
        console.error(`[Odds Sync] Failed to fetch odds for ${sport}: ${res.statusText}`)
        continue
      }

      const events = (await res.json()) as OddsEvent[]
      if (!Array.isArray(events)) continue

      for (const event of events) {
        // Find matching match in DB
        const match = dbMatches.rows.find(m => {
          const timeDiff = Math.abs(new Date(m.start_time).getTime() - new Date(event.commence_time).getTime())
          const isSameDay = timeDiff < 24 * 60 * 60 * 1000 // Within 24 hours
          return (
            isSameDay &&
            ((teamMatches(m.team_a, event.home_team) && teamMatches(m.team_b, event.away_team)) ||
              (teamMatches(m.team_a, event.away_team) && teamMatches(m.team_b, event.home_team)))
          )
        })

        if (!match) continue

        // Get outcomes from first bookmaker that has h2h market
        const bookmaker = event.bookmakers?.[0]
        const market = bookmaker?.markets?.find(m => m.key === 'h2h')
        const outcomes = market?.outcomes
        if (!outcomes || outcomes.length < 2) continue

        // Map outcomes to match teams
        const options = outcomes.map((o, idx) => {
          let key = 'draw'
          if (teamMatches(match.team_a, o.name)) {
            key = 'team_a'
          } else if (teamMatches(match.team_b, o.name)) {
            key = 'team_b'
          } else {
            key = `option_${idx}`
          }
          return {
            key,
            label: o.name,
            odds: Number(o.price),
          }
        })

        // Upsert the match_winner market
        const marketLabel = `${match.team_a} vs ${match.team_b} - Match Winner`
        await db.query(
          `INSERT INTO cricket_markets (match_id, market_type, label, options, status)
           VALUES ($1, 'match_winner', $2, $3, 'open')
           ON CONFLICT (match_id, market_type) 
           DO UPDATE SET options = EXCLUDED.options, label = EXCLUDED.label
           WHERE cricket_markets.status = 'open'`,
          [match.id, marketLabel, JSON.stringify(options)]
        )
      }
    } catch (err: any) {
      console.error(`[Odds Sync] Error syncing sport ${sport}:`, err.message)
    }
  }
}
