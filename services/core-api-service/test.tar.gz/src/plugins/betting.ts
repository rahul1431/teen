import { FastifyInstance } from 'fastify'
import { Pool } from 'pg'
import { z } from 'zod'
import crypto from 'crypto'
import { debitStake, creditPrize } from '../helpers/wallet-client'
import { rebalanceWeeklyMonthlyBotTickets } from '../helpers/lottery-bot-fill'
import { MATKA_MULTIPLIERS, validateMatkaBet, settleMatkaSession } from '../helpers/matka'
import { settleLottery, generateWinningNumber } from '../helpers/lottery'
import { rollOutcome } from '../helpers/scratch'
import { settleCricketSession } from '../helpers/cricket'
import { cricApiFetch } from '../helpers/cricapi-client'
import { syncCurrentMatches } from '../helpers/cricket-sync'
import { finalizeMatch } from '../helpers/cricket-finalize'
import { syncMatchOdds } from '../helpers/odds-api-client'
import { initPool } from '../db/pool'
import { startCricketAutomationScheduler } from '../modules/cricket/scheduler'

export function bettingPlugin(db: Pool) {
  // Initialize the shared pool for lottery/betting modules
  initPool(db)
  startCricketAutomationScheduler()

  return async function (app: FastifyInstance) {

    const auth = app.authenticate
    const internal = async (req: any, reply: any) => {
      const key = process.env.INTERNAL_SERVICE_KEY
      if (!key || req.headers['x-internal-key'] !== key) return reply.code(403).send({ error: 'Forbidden' })
    }

    function uid(req: any): string { return (req.user as any)?.sub }

    async function todayDraw(marketId: string) {
      const today = new Date().toISOString().slice(0, 10)
      const existing = await db.query('SELECT * FROM matka_draws WHERE market_id = $1 AND draw_date = $2', [marketId, today])
      if (existing.rows.length) return existing.rows[0]
      const created = await db.query(`INSERT INTO matka_draws (market_id, draw_date, status) VALUES ($1, $2, 'open') RETURNING *`, [marketId, today])
      return created.rows[0]
    }

    // ══ MATKA ══
    app.get('/matka/markets', { onRequest: [auth] }, async () => {
      const markets = await db.query('SELECT * FROM matka_markets WHERE is_active = true ORDER BY sort_order')
      const out = []
      for (const m of markets.rows) {
        const draw = await todayDraw(m.id)
        out.push({ id: m.id, name: m.name, open_time: m.open_time, close_time: m.close_time, draw_id: draw.id, status: draw.status, open_panna: draw.open_panna, open_digit: draw.open_digit, close_panna: draw.close_panna, close_digit: draw.close_digit, jodi: draw.jodi })
      }
      return { markets: out, multipliers: MATKA_MULTIPLIERS }
    })

    app.post('/matka/bet', { onRequest: [auth] }, async (req, reply) => {
      const body = z.object({ market_id: z.string().uuid(), bet_type: z.string(), session: z.enum(['open', 'close']).default('open'), number: z.string(), amount: z.number().positive() }).parse(req.body)
      const err = validateMatkaBet(body.bet_type, body.number)
      if (err) return reply.code(400).send({ error: err })
      const matkaCfg = await db.query(`SELECT is_active FROM game_configs WHERE game_type = 'matka'`)
      if (matkaCfg.rows.length && matkaCfg.rows[0].is_active === false) return reply.code(403).send({ error: 'Matka betting is currently disabled' })
      const draw = await todayDraw(body.market_id)
      if (draw.status === 'settled') return reply.code(409).send({ error: 'Market closed for today' })
      
      // Sangam bets always depend on close results
      const resolvedSession = body.bet_type.includes('sangam') ? 'close' : body.session
      if (resolvedSession === 'open' && draw.open_panna) return reply.code(409).send({ error: 'Open session already declared' })
      if (resolvedSession === 'close' && draw.close_panna) return reply.code(409).send({ error: 'Close session already declared' })
      
      // Enforce the market's posted betting windows (times are IST). Open bets
      // are accepted until the open cutoff, close bets until the close cutoff.
      const mkt = await db.query(
        `SELECT open_time, close_time, (NOW() AT TIME ZONE 'Asia/Kolkata')::time AS now_ist
         FROM matka_markets WHERE id = $1`,
        [body.market_id],
      )
      if (mkt.rows.length) {
        const { open_time, close_time, now_ist } = mkt.rows[0]
        if (resolvedSession === 'open' && now_ist > open_time) return reply.code(409).send({ error: 'Open betting has closed for today' })
        if (resolvedSession === 'close' && now_ist > close_time) return reply.code(409).send({ error: 'Close betting has closed for today' })
      }
      const multiplier = MATKA_MULTIPLIERS[body.bet_type]
      const potential = Math.round(body.amount * multiplier * 100) / 100
      const betId = crypto.randomUUID()
      const debit = await debitStake({ userId: uid(req), amount: body.amount, referenceId: betId, idempotencyKey: `matka_stake_${betId}`, description: 'Matka bet' })
      if (!debit.ok) return reply.code(400).send({ error: debit.error })
      await db.query(`INSERT INTO matka_bets (id, user_id, draw_id, bet_type, session, number, amount, multiplier, potential_payout) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`, [betId, uid(req), draw.id, body.bet_type, resolvedSession, body.number, body.amount, multiplier, potential])
      return { success: true, bet_id: betId, potential_payout: potential }
    })

    app.get('/matka/my-bets', { onRequest: [auth] }, async (req) => {
      const rows = await db.query(`SELECT b.*, m.name AS market_name FROM matka_bets b JOIN matka_draws d ON d.id = b.draw_id JOIN matka_markets m ON m.id = d.market_id WHERE b.user_id = $1 ORDER BY b.created_at DESC LIMIT 100`, [uid(req)])
      return { bets: rows.rows }
    })

    function getMonday(d: Date) {
      const date = new Date(d)
      const day = date.getDay()
      const diff = date.getDate() - day + (day === 0 ? -6 : 1)
      return new Date(date.setDate(diff)).toISOString().slice(0, 10)
    }

    app.get('/matka/markets/:id/chart', { onRequest: [auth] }, async (req) => {
      const { id } = req.params as { id: string }
      const draws = await db.query(
        `SELECT draw_date, open_panna, open_digit, close_panna, close_digit, jodi, status 
         FROM matka_draws 
         WHERE market_id = $1 
         ORDER BY draw_date DESC LIMIT 100`,
        [id],
      )
      const weeks: Record<string, any> = {}
      for (const row of draws.rows) {
        const d = new Date(row.draw_date)
        const mondayStr = getMonday(d)
        if (!weeks[mondayStr]) {
          weeks[mondayStr] = {
            week_start: mondayStr,
            mon: null, tue: null, wed: null, thu: null, fri: null, sat: null, sun: null
          }
        }
        const days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']
        const dayKey = days[d.getDay()]
        weeks[mondayStr][dayKey] = {
          open_panna: row.open_panna ?? '***',
          close_panna: row.close_panna ?? '***',
          jodi: row.jodi ?? '**',
          open_digit: row.open_digit !== null ? String(row.open_digit) : '*',
          close_digit: row.close_digit !== null ? String(row.close_digit) : '*'
        }
      }
      return { chart: Object.values(weeks).sort((a, b) => b.week_start.localeCompare(a.week_start)) }
    })

    // ══ LOTTERY ══
    app.get('/lottery/draws', { onRequest: [auth] }, async () => {
      const rows = await db.query(`
        SELECT d.*, 
               COALESCE((SELECT json_agg(t.ticket_number) FROM lottery_tickets t WHERE t.draw_id = d.id), '[]'::json) AS reserved_tickets,
               COUNT(t.id)::int AS ticket_count
        FROM lottery_draws d
        LEFT JOIN lottery_tickets t ON t.draw_id = d.id
        WHERE d.status = 'open' AND d.draw_time > NOW()
        GROUP BY d.id
        ORDER BY d.draw_time ASC
      `)
      return { draws: rows.rows }
    })

    app.post('/lottery/buy', { onRequest: [auth] }, async (req, reply) => {
      const body = z.object({ draw_id: z.string().uuid(), ticket_number: z.string() }).parse(req.body)
      const ticketNumClean = body.ticket_number.trim()
      const drawRes = await db.query(`SELECT * FROM lottery_draws WHERE id = $1 AND status = 'open'`, [body.draw_id])
      if (!drawRes.rows.length) return reply.code(409).send({ error: 'Draw not open' })
      const draw = drawRes.rows[0]
      if (!/^[0-9]{4}$/.test(ticketNumClean)) return reply.code(400).send({ error: 'Ticket number must be exactly 4 digits.' })
      const lotteryCfg = await db.query(`SELECT is_active FROM game_configs WHERE game_type = 'lottery'`)
      if (lotteryCfg.rows.length && lotteryCfg.rows[0].is_active === false) return reply.code(403).send({ error: 'Lottery is currently disabled' })
      
      const checkRes = await db.query(`SELECT 1 FROM lottery_tickets WHERE draw_id = $1 AND ticket_number = $2`, [body.draw_id, ticketNumClean])
      if (checkRes.rows.length > 0) return reply.code(409).send({ error: 'Ticket number is already reserved by another player' })
      
      const ticketId = crypto.randomUUID()
      const debit = await debitStake({ userId: uid(req), amount: Number(draw.ticket_price), referenceId: ticketId, idempotencyKey: `lottery_buy_${ticketId}`, description: `Lottery: ${draw.name}` })
      if (!debit.ok) return reply.code(400).send({ error: debit.error })
      
      try {
        await db.query(`INSERT INTO lottery_tickets (id, draw_id, user_id, ticket_number, amount) VALUES ($1,$2,$3,$4,$5)`, [ticketId, body.draw_id, uid(req), ticketNumClean, draw.ticket_price])
      } catch (err: any) {
        await creditPrize({ userId: uid(req), amount: Number(draw.ticket_price), referenceId: ticketId, idempotencyKey: `lottery_buy_refund_${ticketId}` })
        if (err.code === '23505') {
          return reply.code(409).send({ error: 'Ticket number is already reserved' })
        }
        throw err
      }

      try {
        await rebalanceWeeklyMonthlyBotTickets(body.draw_id)
      } catch (err: any) {
        console.error(`[lottery] rebalanceWeeklyMonthlyBotTickets failed for draw ${body.draw_id}:`, err?.message || err)
      }

      return { success: true, ticket_id: ticketId }
    })

    app.get('/lottery/my-tickets', { onRequest: [auth] }, async (req) => {
      const rows = await db.query(`SELECT t.*, d.name AS draw_name, d.winning_number, d.draw_time, d.status AS draw_status, d.category AS draw_category FROM lottery_tickets t JOIN lottery_draws d ON d.id = t.draw_id WHERE t.user_id = $1 ORDER BY t.created_at DESC LIMIT 100`, [uid(req)])
      return { tickets: rows.rows }
    })

    app.get('/lottery/results', { onRequest: [auth] }, async () => {
      const rows = await db.query(`
        SELECT d.*,
          (SELECT json_agg(json_build_object('ticket_number', t.ticket_number, 'prize', t.prize)) 
           FROM lottery_tickets t WHERE t.draw_id = d.id AND t.is_winner = true) AS winners,
          COUNT(t.id)::int AS total_tickets,
          COUNT(t.id) FILTER (WHERE t.is_winner = true)::int AS winner_count,
          COALESCE(SUM(t.prize) FILTER (WHERE t.is_winner = true), 0) AS total_paid
        FROM lottery_draws d
        LEFT JOIN lottery_tickets t ON t.draw_id = d.id
        WHERE d.status = 'settled'
        GROUP BY d.id
        ORDER BY d.draw_time DESC
        LIMIT 20
      `)
      return { draws: rows.rows }
    })

    // ══ LOTTERY — INSTANT (SCRATCH CARD) ══
    app.get('/lottery/scratch/products', { onRequest: [auth] }, async () => {
      const rows = await db.query(`SELECT * FROM lottery_scratch_products WHERE is_active = true ORDER BY price ASC`)
      return { products: rows.rows }
    })

    app.post('/lottery/scratch/buy', { onRequest: [auth] }, async (req, reply) => {
      const body = z.object({ product_id: z.string().uuid() }).parse(req.body)
      const productRes = await db.query(`SELECT * FROM lottery_scratch_products WHERE id = $1 AND is_active = true`, [body.product_id])
      if (!productRes.rows.length) return reply.code(409).send({ error: 'Product not available' })
      const product = productRes.rows[0]

      const ticketId = crypto.randomUUID()
      const debit = await debitStake({ userId: uid(req), amount: Number(product.price), referenceId: ticketId, idempotencyKey: `scratch_buy_${ticketId}`, description: `Scratch Card: ${product.name}` })
      if (!debit.ok) return reply.code(400).send({ error: debit.error })

      const result = rollOutcome(product.payouts)

      try {
        await db.query(
          `INSERT INTO lottery_scratch_tickets (id, product_id, user_id, outcome, amount, promo_code_id) VALUES ($1,$2,$3,$4,$5,$6)`,
          [ticketId, body.product_id, uid(req), result.outcome, result.amount, result.promo_code_id],
        )
      } catch (err) {
        await creditPrize({ userId: uid(req), amount: Number(product.price), referenceId: ticketId, idempotencyKey: `scratch_buy_refund_${ticketId}` })
        return reply.code(500).send({ error: 'Purchase failed, your stake has been refunded' })
      }

      if (result.outcome === 'cash' && result.amount > 0) {
        await creditPrize({
          userId: uid(req),
          amount: result.amount,
          referenceId: ticketId,
          idempotencyKey: `scratch_payout_${ticketId}`,
          notification: { title: 'Scratch Card Win! 🎉', body: `You won ₹${result.amount.toFixed(2)} on ${product.name}!` },
        })
      }

      let promoCode: string | null = null
      if (result.outcome === 'coupon' && result.promo_code_id) {
        const promoRes = await db.query(`SELECT code FROM promo_codes WHERE id = $1`, [result.promo_code_id])
        promoCode = promoRes.rows[0]?.code || null
      }

      return { success: true, ticket_id: ticketId, outcome: result.outcome, amount: result.amount, promo_code: promoCode }
    })

    app.get('/lottery/scratch/my-tickets', { onRequest: [auth] }, async (req) => {
      const rows = await db.query(
        `SELECT t.*, p.name AS product_name, p.price AS product_price, pc.code AS promo_code
         FROM lottery_scratch_tickets t
         JOIN lottery_scratch_products p ON p.id = t.product_id
         LEFT JOIN promo_codes pc ON pc.id = t.promo_code_id
         WHERE t.user_id = $1 ORDER BY t.created_at DESC LIMIT 100`,
        [uid(req)],
      )
      return { tickets: rows.rows }
    })

    // ══ CRICKET (Dream11-style fantasy contests, plus session/fancy
    // betting — match-odds betting stays archived; see archived_cricket_{
    // bets,markets}) ══
    app.get('/cricket/matches', { onRequest: [auth] }, async () => {
      const matches = await db.query(`SELECT * FROM cricket_matches WHERE status IN ('upcoming','live') ORDER BY start_time ASC`)
      const out = []
      for (const m of matches.rows) {
        const sessions = await db.query(`SELECT id, label, min_runs, max_runs, odds_yes, odds_no, status, result_runs FROM cricket_sessions WHERE match_id = $1 AND status = 'open'`, [m.id])
        const markets = await db.query(`SELECT id, market_type, label, options, status FROM cricket_markets WHERE match_id = $1 AND status = 'open'`, [m.id])
        out.push({ ...m, sessions: sessions.rows, markets: markets.rows })
      }
      return { matches: out }
    })

    app.post('/cricket/session/bet', { onRequest: [auth] }, async (req, reply) => {
      const body = z.object({ session_id: z.string().uuid(), selection: z.enum(['yes', 'no']), amount: z.number().positive() }).parse(req.body)
      const sRes = await db.query(`SELECT s.*, mt.status AS match_status FROM cricket_sessions s JOIN cricket_matches mt ON mt.id = s.match_id WHERE s.id = $1`, [body.session_id])
      if (!sRes.rows.length) return reply.code(404).send({ error: 'Session not found' })
      const session = sRes.rows[0]
      if (session.status !== 'open' || session.match_status === 'settled' || session.match_status === 'closed') return reply.code(409).send({ error: 'Session is closed' })
      const odds = body.selection === 'yes' ? Number(session.odds_yes) : Number(session.odds_no)
      const bracket = body.selection === 'yes' ? session.max_runs : session.min_runs
      const potential = Math.round(body.amount * odds * 100) / 100
      const betId = crypto.randomUUID()
      const debit = await debitStake({ userId: uid(req), amount: body.amount, referenceId: betId, idempotencyKey: `cricket_session_stake_${betId}`, description: 'Cricket session bet' })
      if (!debit.ok) return reply.code(400).send({ error: debit.error })
      await db.query(`INSERT INTO cricket_session_bets (id, user_id, match_id, session_id, selection, runs_bracket, amount, potential_payout) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [betId, uid(req), session.match_id, session.id, body.selection, bracket, body.amount, potential])
      return { success: true, bet_id: betId, potential_payout: potential }
    })

    app.get('/cricket/session/my-bets', { onRequest: [auth] }, async (req) => {
      const rows = await db.query(`SELECT b.*, mt.team_a, mt.team_b, mt.series, s.label AS session_label FROM cricket_session_bets b JOIN cricket_matches mt ON mt.id = b.match_id JOIN cricket_sessions s ON s.id = b.session_id WHERE b.user_id = $1 ORDER BY b.created_at DESC LIMIT 100`, [uid(req)])
      return { bets: rows.rows }
    })

    app.get('/cricket/odds/markets', { onRequest: [auth] }, async (req) => {
      const { match_id } = req.query as { match_id?: string }
      let query = "SELECT m.*, mt.team_a, mt.team_b, mt.series, mt.start_time FROM cricket_markets m JOIN cricket_matches mt ON mt.id = m.match_id WHERE m.status = 'open'"
      const params: any[] = []
      if (match_id) {
        query += " AND m.match_id = $1"
        params.push(match_id)
      }
      const res = await db.query(query, params)
      return { markets: res.rows }
    })

    app.post('/cricket/odds/bet', { onRequest: [auth] }, async (req, reply) => {
      const body = z.object({
        market_id: z.string().uuid(),
        option_key: z.string(),
        amount: z.number().positive()
      }).parse(req.body)

      const marketRes = await db.query(
        `SELECT m.*, mt.status AS match_status, mt.start_time 
         FROM cricket_markets m 
         JOIN cricket_matches mt ON mt.id = m.match_id 
         WHERE m.id = $1`,
        [body.market_id]
      )
      if (!marketRes.rows.length) return reply.code(404).send({ error: 'Market not found' })
      const market = marketRes.rows[0]

      if (market.status !== 'open' || ['closed', 'settled'].includes(market.match_status)) {
        return reply.code(409).send({ error: 'Market is closed' })
      }

      if (new Date() >= new Date(market.start_time)) {
        return reply.code(409).send({ error: 'Match has already started' })
      }

      const options = typeof market.options === 'string' ? JSON.parse(market.options) : market.options || []
      const option = options.find((o: any) => o.key === body.option_key)
      if (!option) return reply.code(400).send({ error: 'Invalid option key selected' })

      const odds = Number(option.odds)
      const potential = Math.round(body.amount * odds * 100) / 100
      const betId = crypto.randomUUID()

      const debit = await debitStake({
        userId: uid(req),
        amount: body.amount,
        referenceId: betId,
        idempotencyKey: `cricket_odds_stake_${betId}`,
        description: `Cricket odds bet: ${option.label}`
      })
      if (!debit.ok) return reply.code(400).send({ error: debit.error })

      await db.query(
        `INSERT INTO cricket_bets (id, user_id, match_id, market_id, option_key, option_label, odds, amount, potential_payout) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [betId, uid(req), market.match_id, market.id, body.option_key, option.label, odds, body.amount, potential]
      )

      return { success: true, bet_id: betId, potential_payout: potential }
    })

    app.get('/cricket/odds/my-bets', { onRequest: [auth] }, async (req) => {
      const rows = await db.query(
        `SELECT b.*, mt.team_a, mt.team_b, mt.series, m.label AS market_label 
         FROM cricket_bets b 
         JOIN cricket_matches mt ON mt.id = b.match_id 
         JOIN cricket_markets m ON m.id = b.market_id 
         WHERE b.user_id = $1 
         ORDER BY b.created_at DESC LIMIT 100`,
        [uid(req)]
      )
      return { bets: rows.rows }
    })

    // ══ INTERNAL ══
    app.post('/internal/matka/declare', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({ draw_id: z.string().uuid(), session: z.enum(['open', 'close']), panna: z.string().regex(/^[0-9]{3}$/) }).parse(req.body)
      try {
        const res = await settleMatkaSession(db, body.draw_id, body.session, body.panna)
        return { success: true, ...res }
      } catch (err: any) {
        return reply.code(409).send({ error: err.message || 'Declare failed' })
      }
    })

    app.post('/internal/lottery/create', { onRequest: [internal] }, async (req) => {
      const body = z.object({
        name: z.string(),
        ticket_price: z.number().positive(),
        draw_time: z.string(),
        prize_tiers: z.array(z.object({
          match_type: z.enum(['exact', 'last_3', 'last_2', 'last_1']),
          multiplier: z.number().positive(),
        })).min(1),
        // Only weekly/monthly are creatable today — daily/instant are
        // reserved for the future Card/Bingo and Scratch Card mechanics.
        // The DB's CHECK constraint already allows all four so widening
        // this enum later needs no migration, just this one-line change.
        category: z.enum(['daily', 'weekly', 'monthly']),
      }).parse(req.body)
      const botConfigRes = await db.query('SELECT default_max_tickets FROM lottery_bot_config LIMIT 1')
      const maxTickets = botConfigRes.rows[0]?.default_max_tickets ?? 200
      const r = await db.query(`INSERT INTO lottery_draws (name, ticket_price, draw_time, prize_tiers, category, max_tickets) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`, [body.name, body.ticket_price, body.draw_time, JSON.stringify(body.prize_tiers), body.category, maxTickets])
      try {
        await rebalanceWeeklyMonthlyBotTickets(r.rows[0].id)
      } catch (err: any) {
        console.error(`[lottery] rebalanceWeeklyMonthlyBotTickets failed for newly created draw ${r.rows[0].id}:`, err?.message || err)
      }
      return { success: true, draw: r.rows[0] }
    })

    app.post('/internal/lottery/draw', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({
        draw_id: z.string().uuid(),
        winning_number: z.string().regex(/^[0-9]{4}$/).optional(),
        random: z.boolean().optional(),
      }).parse(req.body)
      const winningNumber = body.random ? generateWinningNumber() : body.winning_number
      if (!winningNumber) return reply.code(400).send({ error: 'winning_number or random must be provided' })
      const res = await settleLottery(db, body.draw_id, winningNumber)
      return { success: true, winning_number: winningNumber, ...res }
    })

    app.post('/internal/lottery/cancel', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({ draw_id: z.string().uuid() }).parse(req.body)
      const drawRes = await db.query(`SELECT * FROM lottery_draws WHERE id = $1 AND status = 'open'`, [body.draw_id])
      if (!drawRes.rows.length) return reply.code(409).send({ error: 'Draw not open or already settled' })
      const tickets = await db.query(`SELECT * FROM lottery_tickets WHERE draw_id = $1`, [body.draw_id])
      await db.query(`UPDATE lottery_draws SET status = 'cancelled' WHERE id = $1`, [body.draw_id])
      await Promise.all(tickets.rows.map((t: any) =>
        creditPrize({ userId: t.user_id, amount: Number(t.amount), referenceId: t.id, idempotencyKey: `lottery_refund_${t.id}` })
      ))
      return { success: true, refunded: tickets.rows.length }
    })

    app.get('/internal/lottery/bot-config', { onRequest: [internal] }, async (_req, reply) => {
      const result = await db.query('SELECT * FROM lottery_bot_config LIMIT 1')
      return reply.send(result.rows[0] || null)
    })

    app.post('/internal/lottery/bot-config', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({
        enabled: z.boolean(),
        default_max_tickets: z.coerce.number().int().positive(),
        fill_pct: z.coerce.number().min(0).max(100),
        trigger_pct: z.coerce.number().min(0).max(100),
        release_pct: z.coerce.number().min(0).max(100),
      }).parse(req.body)
      const result = await db.query(
        `UPDATE lottery_bot_config
         SET enabled = $1, default_max_tickets = $2, fill_pct = $3, trigger_pct = $4, release_pct = $5, updated_at = NOW()
         RETURNING *`,
        [body.enabled, body.default_max_tickets, body.fill_pct, body.trigger_pct, body.release_pct]
      )
      return reply.send(result.rows[0])
    })

    app.post('/internal/lottery/scratch/create', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({
        name: z.string(),
        price: z.number().positive(),
        payouts: z.array(z.object({
          outcome: z.enum(['cash', 'coupon', 'no_win']),
          amount: z.number().positive().optional(),
          promo_code_id: z.string().uuid().optional(),
          probability: z.number().min(0).max(100),
        })).min(1),
      }).parse(req.body)

      const total = body.payouts.reduce((sum, p) => sum + p.probability, 0)
      if (Math.abs(total - 100) > 0.01) return reply.code(400).send({ error: 'Payout probabilities must sum to 100' })
      for (const p of body.payouts) {
        if (p.outcome === 'cash' && p.amount === undefined) return reply.code(400).send({ error: 'Cash payouts require an amount' })
        if (p.outcome === 'coupon' && !p.promo_code_id) return reply.code(400).send({ error: 'Coupon payouts require a promo_code_id' })
      }

      const r = await db.query(
        `INSERT INTO lottery_scratch_products (name, price, payouts) VALUES ($1,$2,$3) RETURNING *`,
        [body.name, body.price, JSON.stringify(body.payouts)],
      )
      return { success: true, product: r.rows[0] }
    })

    // Looks up a cached flag by matching a team/country name against
    // cricket_countries — same fuzzy substring match used by sync-api and
    // import-series-matches, so manually-added matches get flags too instead
    // of relying only on the sync flows.
    async function findCountryFlag(name: string): Promise<string | null> {
      const flagsRes = await db.query('SELECT name, flag_url FROM cricket_countries')
      const n = name?.toLowerCase() || ''
      for (const row of flagsRes.rows) {
        const k = row.name.toLowerCase()
        if (n.includes(k) || k.includes(n)) return row.flag_url
      }
      return null
    }

    // Squad syncs (sync-squad, sync-series-squads) used to match only by
    // external_id, so any pre-existing player row without one (manually
    // seeded, or created before external_id existed) got duplicated the
    // first time a real API sync ran for their team. Falls back to a
    // name+team match and backfills external_id so it's tagged going
    // forward. Also never overwrites role/team_name on an existing row —
    // the API's role string is unreliable (e.g. it mis-tagged wicket-
    // keepers Jos Buttler and KL Rahul as "batsman"), so a curated role
    // shouldn't get clobbered by every sync.
    app.post('/internal/cricket/match', { onRequest: [internal] }, async (req) => {
      const body = z.object({ series: z.string(), format: z.string(), team_a: z.string(), team_b: z.string(), team_a_short: z.string().optional(), team_b_short: z.string().optional(), start_time: z.string() }).parse(req.body)
      const [teamAFlag, teamBFlag] = await Promise.all([findCountryFlag(body.team_a), findCountryFlag(body.team_b)])
      const r = await db.query(`INSERT INTO cricket_matches (series, format, team_a, team_b, team_a_short, team_b_short, start_time, team_a_flag, team_b_flag) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`, [body.series, body.format, body.team_a, body.team_b, body.team_a_short, body.team_b_short, body.start_time, teamAFlag, teamBFlag])
      return { success: true, match: r.rows[0] }
    })

    app.post('/internal/cricket/session/create', { onRequest: [internal] }, async (req) => {
      const body = z.object({ match_id: z.string().uuid(), label: z.string(), min_runs: z.number().int(), max_runs: z.number().int(), odds_yes: z.number().default(1.0), odds_no: z.number().default(1.0) }).parse(req.body)
      const r = await db.query(`INSERT INTO cricket_sessions (match_id, label, min_runs, max_runs, odds_yes, odds_no) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`, [body.match_id, body.label, body.min_runs, body.max_runs, body.odds_yes, body.odds_no])
      return { success: true, session: r.rows[0] }
    })

    app.patch('/internal/cricket/session/:id', { onRequest: [internal] }, async (req, reply) => {
      const { id } = req.params as { id: string }
      const body = z.object({ label: z.string().optional(), min_runs: z.number().int().optional(), max_runs: z.number().int().optional(), odds_yes: z.number().optional(), odds_no: z.number().optional() }).parse(req.body)
      const existing = await db.query('SELECT status FROM cricket_sessions WHERE id = $1', [id])
      if (!existing.rows.length) return reply.code(404).send({ error: 'Session not found' })
      if (existing.rows[0].status === 'settled') return reply.code(409).send({ error: 'Cannot edit a settled session' })
      const fields: string[] = [], params: any[] = [id]
      let i = 2
      for (const [key, val] of Object.entries(body)) {
        if (val === undefined) continue
        fields.push(`${key} = $${i++}`)
        params.push(val)
      }
      if (!fields.length) return reply.code(400).send({ error: 'No fields to update' })
      const res = await db.query(`UPDATE cricket_sessions SET ${fields.join(', ')} WHERE id = $1 RETURNING *`, params)
      return { success: true, session: res.rows[0] }
    })

    // Bulk-create the over-bracket sessions for a match in one call. Sessions
    // are always the same shape — "runs at the end of over N" for a run of
    // consecutive overs — and creating them one at a time is the slowest part
    // of setting a match up. Ranges already covered by an existing session are
    // skipped, so this is safe to re-run as a match progresses.
    app.post('/internal/cricket/session/bulk-create', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({
        match_id: z.string().uuid(),
        label_template: z.string().default('{over} over runs'),
        from_over: z.number().int().min(1),
        to_over: z.number().int().min(1),
        // Expected runs at the first over in the range, and how much that
        // expectation grows per over — together these generate each bracket.
        base_runs: z.number().int().min(0),
        runs_per_over: z.number().min(0).default(8),
        // Bracket width: a session on "45-47" is min 45, max 47.
        bracket_width: z.number().int().min(0).default(2),
        odds_yes: z.number().default(1.0),
        odds_no: z.number().default(1.0),
      }).parse(req.body)

      if (body.to_over < body.from_over) return reply.code(400).send({ error: 'to_over must be greater than or equal to from_over' })

      const mRes = await db.query('SELECT status FROM cricket_matches WHERE id = $1', [body.match_id])
      if (!mRes.rows.length) return reply.code(404).send({ error: 'Match not found' })
      if (['settled', 'closed'].includes(mRes.rows[0].status)) return reply.code(400).send({ error: 'Cannot add sessions to a settled or closed match' })

      const existing = (await db.query('SELECT label FROM cricket_sessions WHERE match_id = $1', [body.match_id]))
        .rows.map(r => String(r.label))

      const created: any[] = []
      const skipped: string[] = []
      for (let over = body.from_over; over <= body.to_over; over++) {
        const label = body.label_template.replace('{over}', String(over))
        if (existing.includes(label)) { skipped.push(label); continue }
        const min = Math.round(body.base_runs + (over - body.from_over) * body.runs_per_over)
        const r = await db.query(
          `INSERT INTO cricket_sessions (match_id, label, min_runs, max_runs, odds_yes, odds_no)
           VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
          [body.match_id, label, min, min + body.bracket_width, body.odds_yes, body.odds_no],
        )
        created.push(r.rows[0])
      }
      return { success: true, created: created.length, skipped, sessions: created }
    })

    app.post('/internal/cricket/session/settle', { onRequest: [internal] }, async (req) => {
      const body = z.object({ session_id: z.string().uuid(), result_runs: z.number().nullable() }).parse(req.body)
      const res = await settleCricketSession(db, body.session_id, body.result_runs)
      return { success: true, ...res }
    })

    app.post('/internal/cricket/fantasy/leagues', { onRequest: [internal] }, async (req) => {
      const body = z.object({ match_id: z.string().uuid(), name: z.string(), entry_fee: z.number().nonnegative(), prize_pool: z.number().nonnegative(), max_entries: z.number().int().positive(), prize_distribution: z.array(z.object({ rank_start: z.number().int().positive(), rank_end: z.number().int().positive(), payout: z.number().positive() })) }).parse(req.body)
      const res = await db.query(`INSERT INTO cricket_fantasy_leagues (match_id, name, entry_fee, prize_pool, max_entries, prize_distribution) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`, [body.match_id, body.name, body.entry_fee, body.prize_pool, body.max_entries, JSON.stringify(body.prize_distribution)])
      return { success: true, league: res.rows[0] }
    })

    app.post('/internal/cricket/scores/update', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({ match_id: z.string().uuid(), live_score: z.any().optional(), live_tv_url: z.string().optional(), status: z.enum(['upcoming', 'live', 'closed', 'settled']).optional() }).parse(req.body)
      const fields: string[] = [], params: any[] = [body.match_id]
      let i = 2
      if (body.live_score) { fields.push(`live_score = $${i++}`); params.push(JSON.stringify(body.live_score)) }
      if (body.live_tv_url !== undefined) { fields.push(`live_tv_url = $${i++}`); params.push(body.live_tv_url || null) }
      if (body.status) { fields.push(`status = $${i++}`); params.push(body.status) }
      if (!fields.length) return reply.code(400).send({ error: 'No fields to update' })
      const res = await db.query(`UPDATE cricket_matches SET ${fields.join(', ')} WHERE id = $1 RETURNING *`, params)
      return { success: true, match: res.rows[0] }
    })

    // Settle/Finalize match winner odds-based bets.
    app.post('/internal/cricket/finalize', { onRequest: [internal] }, async (req, reply) => {
      const body = z.object({ match_id: z.string().uuid() }).parse(req.body)
      try {
        const res = await finalizeMatch(db, body.match_id)
        return { success: true, ...res }
      } catch (e: any) {
        return reply.code(502).send({ error: e.message })
      }
    })

    // Cricket API sync routes (pass-through to external API)
    app.post('/internal/cricket/sync-api', { onRequest: [internal] }, async (req, reply) => {
      try {
        const { insertedIds, updatedCount } = await syncCurrentMatches(db)
        return { success: true, inserted: insertedIds.length, updated: updatedCount }
      } catch (e: any) { return reply.code(500).send({ error: `API Sync failed: ${e.message}` }) }
    })

    app.post('/internal/cricket/sync-countries', { onRequest: [internal] }, async (req, reply) => {
      try {
        const data = await cricApiFetch(db, apiKey => `https://api.cricapi.com/v1/countries?apikey=${apiKey}&offset=0`)
        if (data.status !== 'success') throw new Error(data.reason || 'Failed')
        let count = 0
        for (const c of (data.data || [])) {
          if (!c.id || !c.name || !c.genericFlag) continue
          await db.query(
            `INSERT INTO cricket_countries (id, name, flag_url)
             SELECT $1, $2, $3
             WHERE NOT EXISTS (
               SELECT 1 FROM cricket_countries WHERE lower(name) = lower($2) AND id <> $1
             )
             ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, flag_url = EXCLUDED.flag_url`,
            [c.id.toLowerCase(), c.name, c.genericFlag],
          )
          count++
        }
        return { success: true, count }
      } catch (e: any) { return reply.code(500).send({ error: `Sync countries failed: ${e.message}` }) }
    })

    app.post('/internal/cricket/sync-series', { onRequest: [internal] }, async (req, reply) => {
      const { search } = req.body as any
      try {
        const data = await cricApiFetch(db, apiKey => `https://api.cricapi.com/v1/series?apikey=${apiKey}&offset=0${search ? `&search=${encodeURIComponent(search)}` : ''}`)
        if (data.status !== 'success') throw new Error(data.reason || 'Failed')
        return { success: true, series: (data.data || []).map((s: any) => ({
          id: s.id, name: s.name, startDate: s.startDate, endDate: s.endDate, matchCount: s.matches,
        })) }
      } catch (e: any) { return reply.code(500).send({ error: `Series search failed: ${e.message}` }) }
    })

    app.post('/internal/cricket/import-series-matches', { onRequest: [internal] }, async (req, reply) => {
      const { series_id } = req.body as any
      if (!series_id) return reply.code(400).send({ error: 'series_id is required' })
      try {
        const data = await cricApiFetch(db, apiKey => `https://api.cricapi.com/v1/series_info?apikey=${apiKey}&id=${series_id}`)
        if (data.status !== 'success') throw new Error(data.reason || 'Failed')
        const info = data.data?.info
        const seriesName = info?.name || 'Imported Series'
        await db.query(`INSERT INTO cricket_series (name, api_series_id) VALUES ($1,$2) ON CONFLICT (name) DO UPDATE SET api_series_id = $2`, [seriesName, series_id])

        const flagsRes = await db.query('SELECT name, flag_url FROM cricket_countries')
        const flagMap = new Map(flagsRes.rows.map(r => [r.name.toLowerCase(), r.flag_url]))
        const findFlag = (n: string) => { for (const [k, v] of flagMap) if (n?.toLowerCase().includes(k) || k.includes(n?.toLowerCase())) return v; return null }

        let inserted = 0, updated = 0
        for (const m of (data.data?.matchList || [])) {
          if (!m.id) continue
          const [team_a, team_b] = [m.teams?.[0] || 'Team A', m.teams?.[1] || 'Team B']
          const status = m.matchEnded ? 'settled' : m.matchStarted ? 'live' : 'upcoming'
          const existing = await db.query('SELECT id FROM cricket_matches WHERE match_api_id = $1', [m.id])
          if (existing.rows.length) {
            await db.query(`UPDATE cricket_matches SET status = $1, team_a_flag = $2, team_b_flag = $3 WHERE id = $4`, [status, findFlag(team_a), findFlag(team_b), existing.rows[0].id])
            updated++
          } else {
            await db.query(`INSERT INTO cricket_matches (series, format, team_a, team_b, team_a_short, team_b_short, start_time, match_api_id, status, team_a_flag, team_b_flag) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
              [seriesName, m.matchType || 't20', team_a, team_b, m.teamInfo?.[0]?.shortname || team_a.substring(0,3).toUpperCase(), m.teamInfo?.[1]?.shortname || team_b.substring(0,3).toUpperCase(), m.dateTimeGMT ? `${m.dateTimeGMT}Z` : new Date().toISOString(), m.id, status, findFlag(team_a), findFlag(team_b)])
            inserted++
          }
        }
        return { success: true, series: seriesName, inserted, updated }
      } catch (e: any) { return reply.code(500).send({ error: `Series import failed: ${e.message}` }) }
    })
  }
}
