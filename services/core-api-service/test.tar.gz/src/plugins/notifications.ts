import { FastifyInstance } from 'fastify'
import { Pool } from 'pg'
import Redis from 'ioredis'
import * as admin from 'firebase-admin'

let firebaseInitialized = false

function initFirebase() {
  if (firebaseInitialized || !process.env.FIREBASE_SERVICE_ACCOUNT_JSON) return
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
  if (sa.private_key) {
    sa.private_key = sa.private_key.replace(/\\n/g, '\n')
  }
  admin.initializeApp({ credential: admin.credential.cert(sa) })
  firebaseInitialized = true
}

async function sendPushNotification(fcmToken: string, title: string, body: string, data?: Record<string, string>, imageUrl?: string) {
  if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    console.log(`[PUSH DEV] To: ${fcmToken?.slice(0, 20)}... | ${title}: ${body} | Image: ${imageUrl}`)
    return
  }
  const payload: any = {
    token: fcmToken,
    notification: { title, body },
    data,
    android: { priority: 'high' },
    apns: { payload: { aps: { sound: 'default' } } }
  }
  if (imageUrl) {
    payload.notification.imageUrl = imageUrl
  }
  await admin.messaging().send(payload)
}

export function notificationsPlugin(db: Pool, redis?: Redis) {
  return async function (app: FastifyInstance) {
    initFirebase()

    // Listen for wallet updates from admin/system credits via Redis Pub/Sub
    if (redis) {
      const walletUpdateSub = redis.duplicate()
      walletUpdateSub.subscribe('wallet:updated', async (err) => {
        if (err) console.error('[wallet:updated subscriber] subscription error:', err)
      })

      walletUpdateSub.on('message', async (channel, message) => {
        if (channel !== 'wallet:updated') return
        try {
          const event = JSON.parse(message)
          const { userId, type, amount, walletType } = event

          // Fetch FCM token for this user
          const tokenRes = await db.query('SELECT fcm_token FROM users WHERE id = $1', [userId])
          if (!tokenRes.rows.length || !tokenRes.rows[0].fcm_token) return

          const fcmToken = tokenRes.rows[0].fcm_token
          let title = 'Wallet Updated'
          let body = `₹${amount} added to your ${walletType} balance`
          const data = { walletUpdated: 'true', amount: String(amount), type }

          if (type === 'manual_credit') {
            title = 'Bonus Added ✨'
            body = `₹${amount} bonus has been credited to your account`
          } else if (type === 'deposit') {
            title = 'Deposit Confirmed ✅'
            body = `Your deposit of ₹${amount} has been credited`
          } else if (type === 'referral') {
            title = 'Referral Reward Earned 🎁'
            body = `₹${amount} referral bonus has been added`
          } else if (type === 'game_credit') {
            title = 'Winnings Credited 🎉'
            body = `You won ₹${amount}!`
          }

          await sendPushNotification(fcmToken, title, body, data)
        } catch (err) {
          console.error('[wallet:updated handler] error:', err)
        }
      })

      walletUpdateSub.on('error', (err) => {
        console.error('[wallet:updated subscriber] error:', err)
      })
    }

    const internal = async (req: any, reply: any) => {
      const key = process.env.INTERNAL_SERVICE_KEY
      if (!key || req.headers['x-internal-key'] !== key) return reply.code(403).send({ error: 'Forbidden' })
    }

    app.get('/notifications/me', { onRequest: [app.authenticate] }, async (req, reply) => {
      const user = req.user as any
      const res = await db.query(`SELECT id, type, title, body, data, read, created_at, image_url FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`, [user.sub])
      return reply.send(res.rows)
    })

    app.get('/notifications/unread-count', { onRequest: [app.authenticate] }, async (req, reply) => {
      const user = req.user as any
      const res = await db.query('SELECT COUNT(*)::int AS count FROM notifications WHERE user_id = $1 AND read = false', [user.sub])
      return reply.send({ count: res.rows[0].count })
    })

    app.put('/notifications/read-all', { onRequest: [app.authenticate] }, async (req, reply) => {
      const user = req.user as any
      await db.query('UPDATE notifications SET read = true, read_at = NOW() WHERE user_id = $1 AND read = false', [user.sub])
      return reply.send({ success: true })
    })

    app.delete('/notifications/all', { onRequest: [app.authenticate] }, async (req, reply) => {
      const user = req.user as any
      await db.query('DELETE FROM notifications WHERE user_id = $1', [user.sub])
      return reply.send({ success: true })
    })

    app.put('/notifications/read/:id', { onRequest: [app.authenticate] }, async (req, reply) => {
      const user = req.user as any
      const { id } = req.params as any
      await db.query('UPDATE notifications SET read = true, read_at = NOW() WHERE id = $1 AND user_id = $2', [id, user.sub])
      return reply.send({ success: true })
    })

    // Marks the CALLING user's own notification(s) for a campaign as read
    app.put('/notifications/read-by-campaign/:campaignId', { onRequest: [app.authenticate] }, async (req, reply) => {
      const user = req.user as any
      const { campaignId } = req.params as any
      await db.query(
        'UPDATE notifications SET read = true, read_at = NOW() WHERE campaign_id = $1 AND user_id = $2 AND read = false',
        [campaignId, user.sub],
      )
      return reply.send({ success: true })
    })

    app.post('/internal/notifications/send', { onRequest: [internal] }, async (req, reply) => {
      const { user_id, title, body, type = 'general', data, campaign_id, image_url } = req.body as any
      const pushData = { ...(data || {}), ...(campaign_id ? { campaign_id: String(campaign_id) } : {}) }
      await db.query(
        'INSERT INTO notifications (user_id, type, title, body, data, campaign_id, image_url) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        [user_id, type, title, body, JSON.stringify(pushData), campaign_id || null, image_url || null],
      )
      const userRes = await db.query('SELECT fcm_token FROM users WHERE id = $1', [user_id])
      let delivered = 0
      if (userRes.rows[0]?.fcm_token) {
        await sendPushNotification(userRes.rows[0].fcm_token, title, body, pushData, image_url)
        delivered = 1
      }
      return reply.send({ success: true, delivered })
    })

    app.post('/internal/notifications/broadcast', { onRequest: [internal] }, async (req, reply) => {
      const { title, body, type = 'broadcast', data, campaign_id, image_url, segment_type = 'all' } = req.body as any
      const pushData = { ...(data || {}), ...(campaign_id ? { campaign_id: String(campaign_id) } : {}) }
      
      // Determine segment query
      let userQuery = `SELECT id, fcm_token FROM users WHERE is_bot = false AND status = $1`
      const userParams: any[] = ['active']

      if (segment_type === 'active_7d') {
        userQuery += ` AND last_login_at >= NOW() - INTERVAL '7 days'`
      } else if (segment_type === 'inactive_7d') {
        userQuery += ` AND (last_login_at IS NULL OR last_login_at < NOW() - INTERVAL '7 days')`
      } else if (segment_type === 'low_balance') {
        userQuery = `
          SELECT u.id, u.fcm_token 
          FROM users u
          JOIN wallets w ON w.user_id = u.id
          WHERE u.is_bot = false AND u.status = $1
            AND (w.deposit_balance + w.winning_balance + w.bonus_balance) < 100
        `
      }

      const usersRes = await db.query(userQuery, userParams)
      const users = usersRes.rows
      if (users.length === 0) return reply.send({ success: true, sent: 0, total: 0 })

      // 1. Bulk insert DB notifications in batches of 1000
      const dbBatchSize = 1000
      for (let i = 0; i < users.length; i += dbBatchSize) {
        const batch = users.slice(i, i + dbBatchSize)
        const values: any[] = []
        let queryText = 'INSERT INTO notifications (user_id, type, title, body, data, campaign_id, image_url) VALUES '
        for (let j = 0; j < batch.length; j++) {
          const u = batch[j]
          const offset = j * 7
          queryText += `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6}, $${offset + 7})`
          if (j < batch.length - 1) queryText += ', '
          values.push(u.id, type, title, body, JSON.stringify(pushData), campaign_id || null, image_url || null)
        }
        await db.query(queryText, values)
      }

      // 2. Batch send push notifications using sendEach in batches of 500
      const tokens = users.map(u => u.fcm_token).filter(Boolean) as string[]
      let sent = 0
      if (tokens.length > 0) {
        if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
          console.log(`[PUSH DEV] Broadcasted to ${tokens.length} tokens: ${title}: ${body} | Image: ${image_url}`)
          sent = tokens.length
        } else {
          const fcmMessages = tokens.map(token => {
            const msg: any = {
              token,
              notification: { title, body },
              data: pushData,
              android: { priority: 'high' } as any,
              apns: { payload: { aps: { sound: 'default' } } } as any
            }
            if (image_url) {
              msg.notification.imageUrl = image_url
            }
            return msg
          })
          const fcmBatchSize = 500
          for (let i = 0; i < fcmMessages.length; i += fcmBatchSize) {
            const batch = fcmMessages.slice(i, i + fcmBatchSize)
            try {
              const response = await admin.messaging().sendEach(batch)
              sent += response.successCount
            } catch (err) {
              console.error('[broadcast] FCM batch failed:', err)
            }
          }
        }
      }

      return reply.send({ success: true, sent, total: users.length })
    })
  }
}
